#ifndef ROMS_H
#define ROMS_H

#include <stdbool.h>

typedef enum {
    SYS_2600 = 0,
    SYS_JR,       /* Atari 2600 Junior (same hardware, shown as its own tile) */
    SYS_5200,
    SYS_7800,
    SYS_COUNT
} System;

typedef struct {
    char   path[256];
    char   name[64];   /* display name, no extension */
    System sys;
} Rom;

extern const char *SYSTEM_NAMES[SYS_COUNT];

/* Scan the card for ROMs. Returns number found. */
int  roms_scan(void);
void roms_free(void);

int  roms_total(void);
int  roms_count(System s);
/* i-th ROM of system s (sorted by name), or NULL */
const Rom *roms_get(System s, int i);

/* Locate the emulator .nds for a system, or NULL if not installed. */
const char *roms_find_emulator(System s);

#endif
