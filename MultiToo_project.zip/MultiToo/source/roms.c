#include "roms.h"

#include <dirent.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

const char *SYSTEM_NAMES[SYS_COUNT] = {
    "Atari 2600", "2600 Junior", "Atari 5200", "Atari 7800"
};

#define MAX_DEPTH 6
#define MAX_ROMS  2048

static Rom *g_roms  = NULL;
static int  g_count = 0;

/* Per-system sorted index lists */
static int *g_idx[SYS_COUNT];
static int  g_idx_n[SYS_COUNT];

/* Where we look for emulators (first hit wins). */
static const char *EMU_DIRS[] = {
    "/emulators/", "/emu/", "/roms/emulators/", "/_nds/", "/"
};
static const char *EMU_FILES[SYS_COUNT][3] = {
    { "StellaDS.nds", "Stella-DS.nds", NULL },   /* 2600   */
    { "StellaDS.nds", "Stella-DS.nds", NULL },   /* Junior */
    { "A5200DS.nds",  "5200DS.nds",    NULL },   /* 5200   */
    { "A7800DS.nds",  "7800DS.nds",    NULL },   /* 7800   */
};

static bool contains_ci(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    for (; *hay; hay++)
        if (strncasecmp(hay, needle, n) == 0) return true;
    return false;
}

static bool ext_is(const char *file, const char *ext) {
    const char *dot = strrchr(file, '.');
    return dot && strcasecmp(dot, ext) == 0;
}

/* Returns true and sets *out if the file looks like an Atari ROM. */
static bool classify(const char *path, const char *file, System *out) {
    bool jr_hint = contains_ci(path, "2600jr") || contains_ci(path, "junior");

    if (ext_is(file, ".a52")) { *out = SYS_5200; return true; }
    if (ext_is(file, ".a78")) { *out = SYS_7800; return true; }
    if (ext_is(file, ".jr"))  { *out = SYS_JR;   return true; }
    if (ext_is(file, ".a26")) { *out = jr_hint ? SYS_JR : SYS_2600; return true; }

    /* .bin is ambiguous: decide by folder name, default to 2600 */
    if (ext_is(file, ".bin")) {
        if (contains_ci(path, "5200")) *out = SYS_5200;
        else if (contains_ci(path, "7800")) *out = SYS_7800;
        else *out = jr_hint ? SYS_JR : SYS_2600;
        return true;
    }
    return false;
}

static void add_rom(const char *path, const char *file, System s) {
    if (g_count >= MAX_ROMS) return;
    Rom *r = &g_roms[g_count++];
    strncpy(r->path, path, sizeof(r->path) - 1);
    r->path[sizeof(r->path) - 1] = 0;
    strncpy(r->name, file, sizeof(r->name) - 1);
    r->name[sizeof(r->name) - 1] = 0;
    char *dot = strrchr(r->name, '.');
    if (dot) *dot = 0;
    r->sys = s;
}

static void scan_dir(const char *dir, int depth) {
    if (depth > MAX_DEPTH || g_count >= MAX_ROMS) return;
    DIR *d = opendir(dir);
    if (!d) return;

    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;

        char full[256];
        size_t dl = strlen(dir);
        snprintf(full, sizeof(full), "%s%s%s", dir,
                 (dl && dir[dl - 1] == '/') ? "" : "/", e->d_name);

        if (e->d_type == DT_DIR) {
            /* Skip system folders that never hold ROMs */
            if (strcasecmp(e->d_name, "_nds") == 0 ||
                strcasecmp(e->d_name, "emulators") == 0 ||
                strcasecmp(e->d_name, "System Volume Information") == 0)
                continue;
            scan_dir(full, depth + 1);
        } else {
            System s;
            if (classify(full, e->d_name, &s)) add_rom(full, e->d_name, s);
        }
    }
    closedir(d);
}

static int cmp_idx(const void *a, const void *b) {
    return strcasecmp(g_roms[*(const int *)a].name, g_roms[*(const int *)b].name);
}

int roms_scan(void) {
    roms_free();
    g_roms = calloc(MAX_ROMS, sizeof(Rom));
    if (!g_roms) return 0;

    /* /roms first (fast path), then the whole card as a fallback */
    scan_dir("/roms", 0);
    if (g_count == 0) scan_dir("/", 0);

    for (int s = 0; s < SYS_COUNT; s++) {
        g_idx[s] = malloc(sizeof(int) * (g_count ? g_count : 1));
        g_idx_n[s] = 0;
    }
    for (int i = 0; i < g_count; i++) {
        System s = g_roms[i].sys;
        g_idx[s][g_idx_n[s]++] = i;
    }
    for (int s = 0; s < SYS_COUNT; s++)
        qsort(g_idx[s], g_idx_n[s], sizeof(int), cmp_idx);

    return g_count;
}

void roms_free(void) {
    free(g_roms);
    g_roms = NULL;
    g_count = 0;
    for (int s = 0; s < SYS_COUNT; s++) {
        free(g_idx[s]);
        g_idx[s] = NULL;
        g_idx_n[s] = 0;
    }
}

int roms_total(void) { return g_count; }
int roms_count(System s) { return g_idx_n[s]; }

const Rom *roms_get(System s, int i) {
    if (i < 0 || i >= g_idx_n[s]) return NULL;
    return &g_roms[g_idx[s][i]];
}

const char *roms_find_emulator(System s) {
    static char path[256];
    struct stat st;
    for (int d = 0; d < (int)(sizeof(EMU_DIRS) / sizeof(EMU_DIRS[0])); d++)
        for (int f = 0; EMU_FILES[s][f]; f++) {
            snprintf(path, sizeof(path), "%s%s", EMU_DIRS[d], EMU_FILES[s][f]);
            if (stat(path, &st) == 0) return path;
        }
    return NULL;
}
