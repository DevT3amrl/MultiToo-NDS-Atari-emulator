/*
 * MultiToo - Atari 2600 / 2600 Junior / 5200 / 7800 launcher for Nintendo DS.
 *
 * Top screen    : info / status
 * Bottom screen : home screen (4 touch tiles) and the ROM browser
 *
 * Controls
 *   Home  : D-pad or touch to pick a console, A / tap to open, Y rescan
 *   List  : Up/Down/L/R scroll, A or double-tap to launch, B back
 */
#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>

#include "roms.h"
#include "nds_loader_arm9.h"

#define ROWS_PER_PAGE 18
#define LIST_FIRST_ROW 3

static PrintConsole topCon, botCon;

typedef enum { ST_HOME, ST_LIST } State;

/* ---------- small helpers ---------- */

static void at(int row, int col) { iprintf("\x1b[%d;%dH", row, col); }
static void clr(void) { iprintf("\x1b[2J"); }

static void trunc_copy(char *dst, const char *src, int max) {
    strncpy(dst, src, max);
    dst[max] = 0;
}

/* ---------- home screen ---------- */

/* Tile geometry in character cells (32x24 grid) */
static const int TILE_COL[SYS_COUNT] = { 1, 17, 1, 17 };
static const int TILE_ROW[SYS_COUNT] = { 3, 3, 13, 13 };
#define TILE_W 14
#define TILE_H 8

static void draw_tile(System s, bool sel) {
    int r = TILE_ROW[s], c = TILE_COL[s];
    char line[TILE_W + 1];

    for (int y = 0; y < TILE_H; y++) {
        at(r + y, c);
        if (y == 0 || y == TILE_H - 1) {
            memset(line, sel ? '=' : '-', TILE_W);
        } else {
            memset(line, ' ', TILE_W);
            line[0] = line[TILE_W - 1] = sel ? '#' : '|';
        }
        line[TILE_W] = 0;
        iprintf("%s", line);
    }

    /* system name */
    char buf[TILE_W + 1];
    const char *nm = SYSTEM_NAMES[s];
    at(r + 2, c + 1 + (TILE_W - 2 - (int)strlen(nm)) / 2);
    iprintf("%s", nm);

    /* ROM count */
    snprintf(buf, sizeof(buf), "%d ROMs", roms_count(s));
    at(r + 4, c + 1 + (TILE_W - 2 - (int)strlen(buf)) / 2);
    iprintf("%s", buf);

    /* emulator status */
    const char *st = roms_find_emulator(s) ? "ready" : "no emu!";
    at(r + 6, c + 1 + (TILE_W - 2 - (int)strlen(st)) / 2);
    iprintf("%s", st);
}

static void draw_home(int sel) {
    consoleSelect(&botCon);
    clr();
    at(1, 8);  iprintf("-- MULTITOO --");
    for (int s = 0; s < SYS_COUNT; s++) draw_tile((System)s, s == sel);
    at(22, 2); iprintf("A/tap: open   Y: rescan");

    consoleSelect(&topCon);
    clr();
    at(2, 9);  iprintf("M U L T I T O O");
    at(4, 4);  iprintf("Atari launcher for DS");
    at(7, 2);  iprintf("ROMs found : %d", roms_total());
    at(9, 2);  iprintf("Selected   : %s", SYSTEM_NAMES[sel]);
    const char *emu = roms_find_emulator((System)sel);
    at(11, 2); iprintf("Emulator   : %s", emu ? "found" : "MISSING");
    if (emu) {
        char p[30];
        trunc_copy(p, emu, 28);
        at(12, 2); iprintf("%s", p);
    } else {
        at(13, 2); iprintf("Put the .nds in /emulators/");
    }
    at(17, 2); iprintf("ROM folder : /roms/");
    at(18, 2); iprintf("Ext: .a26 .a52 .a78 .bin .jr");
    at(20, 2); iprintf("Tip: folders named 2600jr,");
    at(21, 2); iprintf("5200 or 7800 sort .bin files");
}

static int tile_at_touch(int px, int py) {
    int col = px / 8, row = py / 8;
    for (int s = 0; s < SYS_COUNT; s++)
        if (col >= TILE_COL[s] && col < TILE_COL[s] + TILE_W &&
            row >= TILE_ROW[s] && row < TILE_ROW[s] + TILE_H)
            return s;
    return -1;
}

/* ---------- list screen ---------- */

static void draw_list(System s, int sel, int top) {
    int n = roms_count(s);

    consoleSelect(&botCon);
    clr();
    at(0, 0);  iprintf("%s  (%d)", SYSTEM_NAMES[s], n);
    at(1, 0);  iprintf("--------------------------------");

    if (n == 0) {
        at(5, 2); iprintf("No ROMs found for this");
        at(6, 2); iprintf("console. Put them in /roms/");
    }

    for (int i = 0; i < ROWS_PER_PAGE; i++) {
        int idx = top + i;
        if (idx >= n) break;
        const Rom *r = roms_get(s, idx);
        char nm[28];
        trunc_copy(nm, r->name, 27);
        at(LIST_FIRST_ROW + i, 0);
        iprintf("%c%s", idx == sel ? '>' : ' ', nm);
    }

    at(22, 0); iprintf("A:play B:back L/R:page");
    if (n > ROWS_PER_PAGE) {
        at(23, 0); iprintf("%d/%d", sel + 1, n);
    }

    consoleSelect(&topCon);
    clr();
    at(1, 1); iprintf("%s", SYSTEM_NAMES[s]);
    const Rom *r = roms_get(s, sel);
    if (r) {
        char nm[31];
        trunc_copy(nm, r->name, 30);
        at(4, 1); iprintf("%s", nm);
        at(7, 1); iprintf("Path:");
        /* wrap path over 3 lines */
        for (int l = 0; l < 3; l++) {
            size_t off = (size_t)l * 30;
            if (off >= strlen(r->path)) break;
            char seg[31];
            trunc_copy(seg, r->path + off, 30);
            at(8 + l, 1); iprintf("%s", seg);
        }
        const char *emu = roms_find_emulator(s);
        at(13, 1); iprintf("Emulator: %s", emu ? "ready" : "MISSING");
        if (!emu) {
            at(15, 1); iprintf("Install it in /emulators/");
        }
    }
}

/* Row index in the list for a touch y (or -1) */
static int list_row_at(int py, int top, int n) {
    int row = py / 8;
    int i = row - LIST_FIRST_ROW;
    if (i < 0 || i >= ROWS_PER_PAGE) return -1;
    return (top + i < n) ? top + i : -1;
}

/* ---------- launching ---------- */

static void message(const char *l1, const char *l2) {
    consoleSelect(&topCon);
    at(19, 1); iprintf("%-30s", l1);
    at(20, 1); iprintf("%-30s", l2 ? l2 : "");
}

/* Returns only on failure */
static void launch(const Rom *r) {
    const char *emu = roms_find_emulator(r->sys);
    if (!emu) {
        message("Emulator not found!", "Put it in /emulators/");
        return;
    }
    message("Launching...", NULL);

    const char *argv[3] = { emu, r->path, NULL };
    int rc = runNdsFile(emu, 2, argv);
    /* only reached if the load failed */
    char b[32];
    snprintf(b, sizeof(b), "Launch failed (%d)", rc);
    message(b, "Check the emulator file");
}

/* ---------- main ---------- */

int main(void) {
    videoSetMode(MODE_0_2D);
    videoSetModeSub(MODE_0_2D);
    vramSetBankA(VRAM_A_MAIN_BG);
    vramSetBankC(VRAM_C_SUB_BG);
    consoleInit(&topCon, 0, BgType_Text4bpp, BgSize_T_256x256, 31, 0, true, true);
    consoleInit(&botCon, 0, BgType_Text4bpp, BgSize_T_256x256, 31, 0, false, true);

    keysSetRepeat(15, 4);

    consoleSelect(&topCon);
    at(10, 6); iprintf("MultiToo starting...");

    if (!fatInitDefault()) {
        consoleSelect(&botCon);
        clr();
        at(8, 2);  iprintf("SD / flash card not found");
        at(10, 2); iprintf("Check your DLDI patch.");
        at(11, 2); iprintf("(R4 Gold / Twilight++)");
        while (pmMainLoop()) swiWaitForVBlank();
        return 1;
    }

    consoleSelect(&topCon);
    at(12, 6); iprintf("Scanning ROMs...");
    roms_scan();

    State state = ST_HOME;
    int home_sel = 0;
    System cur = SYS_2600;
    int sel = 0, top = 0;
    int last_tap = -1;

    draw_home(home_sel);

    while (pmMainLoop()) {
        swiWaitForVBlank();
        scanKeys();
        int down = keysDownRepeat();
        int pressed = keysDown();
        touchPosition t = { 0, 0 };
        bool touched = (pressed & KEY_TOUCH) != 0;
        if (touched) touchRead(&t);

        if (state == ST_HOME) {
            bool redraw = false, open = false;

            if (down & KEY_LEFT)  { if (home_sel % 2 == 1) home_sel--; redraw = true; }
            if (down & KEY_RIGHT) { if (home_sel % 2 == 0) home_sel++; redraw = true; }
            if (down & KEY_UP)    { if (home_sel >= 2) home_sel -= 2; redraw = true; }
            if (down & KEY_DOWN)  { if (home_sel < 2) home_sel += 2; redraw = true; }
            if (pressed & KEY_A)  open = true;

            if (touched) {
                int s = tile_at_touch(t.px, t.py);
                if (s >= 0) { home_sel = s; open = true; }
            }
            if (pressed & KEY_Y) {
                consoleSelect(&topCon);
                at(22, 2); iprintf("Rescanning...");
                roms_scan();
                redraw = true;
            }

            if (open) {
                cur = (System)home_sel;
                sel = 0; top = 0; last_tap = -1;
                state = ST_LIST;
                draw_list(cur, sel, top);
            } else if (redraw) {
                draw_home(home_sel);
            }
        } else { /* ST_LIST */
            int n = roms_count(cur);
            bool redraw = false;

            if (down & KEY_UP)   { if (sel > 0) sel--; redraw = true; }
            if (down & KEY_DOWN) { if (sel < n - 1) sel++; redraw = true; }
            if (down & KEY_L)    { sel -= ROWS_PER_PAGE; if (sel < 0) sel = 0; redraw = true; }
            if (down & KEY_R)    { sel += ROWS_PER_PAGE; if (sel > n - 1) sel = n - 1; redraw = true; }
            if (n == 0) sel = 0;

            if (pressed & KEY_B) {
                state = ST_HOME;
                draw_home(home_sel);
                continue;
            }

            bool play = (pressed & KEY_A) && n > 0;

            if (touched) {
                int i = list_row_at(t.py, top, n);
                if (i >= 0) {
                    if (i == sel && last_tap == i) play = true;
                    sel = i; last_tap = i;
                    redraw = true;
                } else if (t.py >= 22 * 8) {
                    state = ST_HOME;           /* tap footer = back */
                    draw_home(home_sel);
                    continue;
                }
            }

            /* keep selection on screen */
            if (sel < top) top = sel;
            if (sel >= top + ROWS_PER_PAGE) top = sel - ROWS_PER_PAGE + 1;

            if (redraw) draw_list(cur, sel, top);
            if (play) launch(roms_get(cur, sel));
        }
    }
    return 0;
}
